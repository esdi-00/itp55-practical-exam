package org.rocs.itp54.appliance_system;

import org.rocs.itp54.appliance_system.operatable.Operatable;

public class ApplianceSystem implements Operatable {
    private String brandName;
    private String wattage;
    private String warrantyProperties;

    public ApplianceSystem(){

    }
    public ApplianceSystem(String brandName, String wattage, String warrantyProperties) {
        this.brandName = brandName;
        this.wattage = wattage;
        this.warrantyProperties = warrantyProperties;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getWattage() {
        return wattage;
    }

    public void setWattage(String wattage) {
        this.wattage = wattage;
    }

    public String getWarrantyProperties() {
        return warrantyProperties;
    }

    public void setWarrantyProperties(String warrantyProperties) {
        this.warrantyProperties = warrantyProperties;
    }
}
