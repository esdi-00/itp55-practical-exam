package org.rocs.itp54.appliance_system.computer;

public class Ram {
}
