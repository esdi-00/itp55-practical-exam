package org.rocs.itp54.appliance_system.computer;

import org.rocs.itp54.appliance_system.ApplianceSystem;

public class Computer extends ApplianceSystem {
    private String operatingSystem;


}
