package org.rocs.itp54.appliance_system.exception;

public class InvalidQualityException extends Exception{
    public InvalidQualityException() {
    }
    public InvalidQualityException(String message) { // throws invalid message
        super(message);
    }
}
