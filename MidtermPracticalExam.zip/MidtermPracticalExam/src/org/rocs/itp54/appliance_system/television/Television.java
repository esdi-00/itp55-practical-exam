package org.rocs.itp54.appliance_system.television;

import org.rocs.itp54.appliance_system.ApplianceSystem;

public class Television extends ApplianceSystem {

    private String channel;
    private String maxChannelNumber;


    public Television(String brandName, String wattage, String warrantyProperties, String channel, String maxChannelNumber) {
        super(brandName, wattage, warrantyProperties);
        this.channel = channel;
        this.maxChannelNumber = maxChannelNumber;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getMaxChannelNumber() {
        return maxChannelNumber;
    }

    public void setMaxChannelNumber(String maxChannelNumber) {
        this.maxChannelNumber = maxChannelNumber;
    }
}
