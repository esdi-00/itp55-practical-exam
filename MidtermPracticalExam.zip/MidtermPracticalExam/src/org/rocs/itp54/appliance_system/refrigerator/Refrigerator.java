package org.rocs.itp54.appliance_system.refrigerator;

import org.rocs.itp54.appliance_system.ApplianceSystem;

public class Refrigerator extends ApplianceSystem {
    private double temperature;

    public Refrigerator(String brandName, String wattage, String warrantyProperties, double temperature) {
        super(brandName, wattage, warrantyProperties);
        this.temperature = temperature;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
}
