package org.rocs.itp54.appliance_system.channel;

import org.rocs.itp54.appliance_system.quality.Quality;

public class Channel{
    private String channelNumber;
    private String channelName;
    Quality quality;

    public Channel(){

    }

    public Channel(String channelNumber, String channelName, Quality quality) {
        this.channelNumber = channelNumber;
        this.channelName = channelName;
        this.quality = quality;
    }

    public String getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Quality getQuality() {
        return quality;
    }

    public void setQuality(Quality quality) {
        this.quality = quality;
    }
}
