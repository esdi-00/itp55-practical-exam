package org.rocs.itp54.appliance_system.operatable;

public interface Operatable {

}
