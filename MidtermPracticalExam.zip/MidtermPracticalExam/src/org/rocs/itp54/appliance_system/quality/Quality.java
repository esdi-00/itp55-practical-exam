package org.rocs.itp54.appliance_system.quality;

public enum Quality {
    StandardDefinition,
    HighDefinition,
    FullHD,
    UltraHD;
}
